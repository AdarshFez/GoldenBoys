(global["webpackJsonp"] = global["webpackJsonp"] || []).push([[5],{

/***/ 483:
/***/ (function(module, exports) {

module.exports = "<!-- <BottomNavigation>\r\n    <TabStrip iosIconRenderingMode=\"alwaysOriginal\">\r\n\r\n        <TabStripItem>\r\n            <Label text=\"Players Tab\"></Label>\r\n            <Image src=\"font://&#xf007;\" class=\"fas t-36\"></Image>\r\n        </TabStripItem>\r\n        <TabStripItem>\r\n            <Label text=\"Teams Tab\"></Label>\r\n            <Image src=\"font://&#xf0c0;\" class=\"fas t-36\"></Image>\r\n        </TabStripItem>\r\n\r\n    </TabStrip>\r\n\r\n    <TabContentItem>\r\n        <page-router-outlet name=\"playerTab\" actionBarVisibility=\"never\"></page-router-outlet>\r\n    </TabContentItem>\r\n\r\n    <TabContentItem>\r\n        <page-router-outlet name=\"teamTab\" actionBarVisibility=\"never\"></page-router-outlet>\r\n    </TabContentItem>\r\n\r\n</BottomNavigation> -->\r\n\r\n<BottomNavigation >\r\n    <TabStrip>\r\n\r\n        <TabStripItem class=\"navigation__item\">\r\n            <Label text=\"Donations\"></Label>\r\n            <Image src=\"font://&#xf015;\" class=\"fas t-36\"></Image>\r\n        </TabStripItem>\r\n\r\n        <TabStripItem class=\"navigation__item\">\r\n            <Label text=\"Good as Gold\"></Label>\r\n            <Image src=\"font://&#xf1ea;\" class=\"far t-36\"></Image>\r\n        </TabStripItem>\r\n\r\n        <TabStripItem class=\"navigation__item\">\r\n            <Label text=\"Events\"></Label>\r\n            <Image src=\"font://&#xf002;\" class=\"fas t-36\"></Image>\r\n        </TabStripItem>\r\n    </TabStrip>\r\n\r\n    <TabContentItem>\r\n        <page-router-outlet name=\"homeTab\"></page-router-outlet>\r\n    </TabContentItem>\r\n\r\n    <TabContentItem>\r\n        <page-router-outlet name=\"browseTab\"></page-router-outlet>\r\n    </TabContentItem>\r\n\r\n    <TabContentItem>\r\n        <page-router-outlet name=\"searchTab\"></page-router-outlet>\r\n    </TabContentItem>\r\n</BottomNavigation>\r\n\r\n<!--\r\n                Note TabStripItem will only accept single Label and/or single Image elements that it\r\n                will \"adopt\"; any other layout elements you try to specify will be ignored\r\n-->\r\n<!-- <StackLayout>\r\n<label text = \"hello from tabs\"></label>\r\n<label text = \"hello from tabs\"></label>\r\n<label text = \"hello from tabs\"></label>\r\n<label text = \"hello from tabs\"></label>\r\n</StackLayout> -->\r\n"

/***/ }),

/***/ 484:
/***/ (function(module, exports) {

module.exports = "/* Add mobile styles for the component here.  */\r\n"

/***/ }),

/***/ 496:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ../node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js
var core = __webpack_require__(0);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/router/index.js
var router = __webpack_require__(89);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/common.js
var common = __webpack_require__(178);

// EXTERNAL MODULE: ../node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js
var fesm5_router = __webpack_require__(74);

// CONCATENATED MODULE: ./app/tabs/tabs.component.ts



var tabs_component_TabsComponent = /** @class */ (function () {
    function TabsComponent(routerExtension, activeRoute) {
        this.routerExtension = routerExtension;
        this.activeRoute = activeRoute;
    }
    TabsComponent.prototype.ngOnInit = function () {
        // tslint:disable-next-line: max-line-length
        //this.routerExtension.navigate([{ outlets: { playerTab: ["players"], teamTab: ["teams"], donationsTab: ["donations"] } }], { relativeTo: this.activeRoute });
        // tslint:disable-next-line: max-line-length
        this.routerExtension.navigate([{ outlets: { homeTab: ["home"], browseTab: ["browse"], searchTab: ["search"] } }], { relativeTo: this.activeRoute });
        //, browseTab: ["default"], searchTab: ["default"]
        // homeTab: ["home"],
        //  browseTab: ["browse"]
    };
    TabsComponent.ctorParameters = function () { return [
        { type: router["RouterExtensions"] },
        { type: fesm5_router["ActivatedRoute"] }
    ]; };
    TabsComponent = __decorate([
        Object(core["Component"])({
            selector: "ns-tabs",
            template: __importDefault(__webpack_require__(483)).default,
            styles: [__importDefault(__webpack_require__(484)).default]
        }),
        __metadata("design:paramtypes", [router["RouterExtensions"],
            fesm5_router["ActivatedRoute"]])
    ], TabsComponent);
    return TabsComponent;
}());


// CONCATENATED MODULE: ./app/tabs/tabs.module.ts
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsModule", function() { return tabs_module_TabsModule; });




// (homeTab:home/default//browseTab:browse/default//searchTab:search/default)
var tabs_module_TabsModule = /** @class */ (function () {
    function TabsModule() {
    }
    TabsModule = __decorate([
        Object(core["NgModule"])({
            imports: [
                common["NativeScriptCommonModule"],
                router["NativeScriptRouterModule"],
                router["NativeScriptRouterModule"].forChild([
                    { path: "", redirectTo: "default" },
                    {
                        path: "default", component: tabs_component_TabsComponent, children: [
                            {
                                path: "home",
                                outlet: "homeTab",
                                component: router["NSEmptyOutletComponent"],
                                loadChildren: function () { return __webpack_require__.e(/* import() */ 4).then(__webpack_require__.bind(null, 494)).then(function (m) { return m.HomeModule; }); }
                            },
                            {
                                path: "browse",
                                outlet: "browseTab",
                                component: router["NSEmptyOutletComponent"],
                                loadChildren: function () { return __webpack_require__.e(/* import() */ 3).then(__webpack_require__.bind(null, 495)).then(function (m) { return m.BrowseModule; }); }
                            },
                            {
                                path: "search",
                                component: router["NSEmptyOutletComponent"],
                                outlet: "searchTab",
                                loadChildren: function () { return __webpack_require__.e(/* import() */ 6).then(__webpack_require__.bind(null, 497)).then(function (m) { return m.SearchModule; }); }
                            }
                        ]
                    }
                ])
            ],
            declarations: [
                tabs_component_TabsComponent
            ],
            providers: [],
            schemas: [core["NO_ERRORS_SCHEMA"]]
        })
    ], TabsModule);
    return TabsModule;
}());



/***/ })

}]);