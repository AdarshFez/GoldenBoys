(global["webpackJsonp"] = global["webpackJsonp"] || []).push([[3],{

/***/ 489:
/***/ (function(module, exports) {

module.exports = "<ActionBar class = \"title\">\n    <!-- <GridLayout> -->\n\n        <GridLayout>\n            <Label class = \"titleText\" text=\"Good as Gold\"></Label>\n            <button class = \"command\" text = Options (tap) = \"toggleMenu()\"></button>\n\n        </GridLayout>\n    <!-- </GridLayout> -->\n</ActionBar>\n\n<DockLayout   *ngIf =\"!menuIsOpen\" >\n    <!-- <Button class = \"Find Length\" text=\"refresh \" (tap)=\"length()\" ></Button>\n    Button class = \"sending to server\" text=\"refresh \" (tap)=\"test()\" ></Button> -->\n\n    <StackLayout  class = ff dock=\"top\" [height] = itemHeight [width] = devWidth>\n        <label text = \"Golden Message\" class = \"header\"></label>\n        <label class = \"mess\" *ngIf=\"firstTime\" text = \"Hit Options and refresh for lastest Message!\"></label>\n        <label class = \"mess\" [text] = \"goldMsg\" textWrap = \"true\"></label>\n    </StackLayout>\n\n\n    <StackLayout class = ff dock=\"top\" [height] = itemHeight-100 [width] = devWidth>\n        <label text = \"Our Current Event\" class = \"header\" ></label>\n        <label class = \"mess\" [text] = \"currentEvent\" textWrap = \"true\"></label>\n    </StackLayout>\n\n    <StackLayout class = ff dock=\"top\" [height] = itemHeight [width] = devWidth>\n        <label text = \"Our Mission\" class = \"header\"></label>\n        <label class = \"mess\" [text] = \"missionStatement\" textWrap = \"true\"></label>\n    </StackLayout>\n\n    <StackLayout class = ff dock=\"top\" [height] = itemHeight [width] = devWidth>\n        <label text = \"Shout out to our sponsors\" class = \"header\"></label>\n        <label class = \"mess\" [text] = \"sponsors\" textWrap = \"true\"></label>\n        <label class = \"mess\" *ngIf=\"firstTime\" text = \"Hit Options and refresh for lastest Message!\"></label>\n    </StackLayout>\n</DockLayout>\n\n<StackLayout *ngIf =\"menuIsOpen\"  >\n\n\n        <Button class = \"command\" text=\"Admin\" [nsRouterLink]=\"['../edit']\" pageTransition=\"slide\" ></Button>\n\n        <Button class = \"command\" text=\"refresh \" (tap)=\"refresh()\" ></Button>\n\n        <Button class = \"command\" text=\"Log Out \" [nsRouterLink]=\"['']\"> </Button>\n\n        <Button text=\"close menu\" class=\"menu-item\" (tap)= \"toggleMenu()\"></Button>\n\n</StackLayout>\n\n\n"

/***/ }),

/***/ 490:
/***/ (function(module, exports) {

module.exports = ".div {\n    padding-top: 1px;\n}\n\n\n\n.ff {\n\n    align-items: center;\n    border-width: 2px;\n    border-color: gold;\n\n}\n\n.GoldMsg {\n\n    align-self: center;\n    align-items: center;\n    border-width: 2px;\n    border-color: gold;\n}\n\n.header {\n    text-align: center;\n    font-weight: bold;\n    font-size: 14px;\n}\n\n.mess{\n    text-align: center;\n}\n"

/***/ }),

/***/ 491:
/***/ (function(module, exports) {

module.exports = "<ActionBar class = \"title\">\r\n    <Label text=\"Edit Menu\"></Label>\r\n    <NavigationButton (tap)=\"onBackTap()\" android.systemIcon=\"ic_menu_back\"></NavigationButton>\r\n</ActionBar>\r\n\r\n<StackLayout class = form [formGroup]=\"form\">\r\n\r\n    <label *ngIf=\"admin\" text =\"Welcome to the Edit Menu for the Messeges\"></label>\r\n    <label *ngIf=\"!admin\" class=\"miniTitle\" text =\"Sorry You are not an Admin, enter admin Password in log or contact Golden Boys\"></label>\r\n    <!-- Email Login -->\r\n    <button text= \"are you admin\" (tap) = \"isAdmin()\"></button>\r\n    <button text= \"Check Again\" (tap) = checkAgain();></button>\r\n\r\n    <StackLayout *ngIf=\"admin\" class = \"form1\" [formGroup]=\"form\">\r\n    <Label class =\"label\"\r\n        [ngClass]=\"{ invald: !emailControlIsValid }\"\r\n    ></Label>\r\n    <TextField\r\n        class =\"input\"\r\n        returnKeyType=\"done\"\r\n        keyboardType=\"Email\"\r\n        [autocorrect] = \"false\"\r\n        autocapitalizationType=\"none\"\r\n        formControlName=\"email\"\r\n        #emailEL\r\n    ></TextField>\r\n\r\n    <label *ngIf=\"!emailControlIsValid\" text =\"please enter a valid Email\"></label>\r\n\r\n    <Button text=\"admin\" (tap) = \"makeAdmin()\" ></Button>\r\n    </StackLayout>\r\n</StackLayout>\r\n"

/***/ }),

/***/ 492:
/***/ (function(module, exports) {

module.exports = "/* Add mobile styles for the component here.  */\r\n.title {\r\n    color: black;\r\n    background-color: gold;\r\n}\r\n\r\n.form {\r\n    background-color: lightgray;\r\n    color: black;\r\n}\r\n\r\n.miniTitle{\r\n    color: black;\r\n    text-align: center;\r\n}\r\n"

/***/ }),

/***/ 495:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ../node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js
var core = __webpack_require__(0);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/common.js
var common = __webpack_require__(178);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/router/index.js
var router = __webpack_require__(89);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/http-client/index.js
var http_client = __webpack_require__(180);

// EXTERNAL MODULE: ../node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js
var fesm5_forms = __webpack_require__(27);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/forms/index.js
var angular_forms = __webpack_require__(179);

// EXTERNAL MODULE: ../node_modules/@nativescript/core/platform/platform.js
var platform = __webpack_require__(20);

// EXTERNAL MODULE: ../node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js
var http = __webpack_require__(66);

// CONCATENATED MODULE: ./app/shared/notes.service.ts


var notes_service_MsgService = /** @class */ (function () {
    function MsgService(http) {
        this.http = http;
        this.url = "https://goldenboys-be087.firebaseio.com/msg.json";
        this.msg = new Array();
        this.arr = new Array();
    }
    MsgService.prototype.pushh = function () {
        alert("sent to service");
        this.http.put(this.url, this.arr).subscribe();
    };
    MsgService.prototype.onGetData = function () {
        var _this = this;
        this.http.get(this.url).subscribe(function (data) { return _this.arr = data; });
    };
    MsgService.prototype.getData = function (num) {
        return this.arr[num];
    };
    MsgService.prototype.getL = function () {
        alert(this.arr.length);
    };
    MsgService.ctorParameters = function () { return [
        { type: http["HttpClient"] }
    ]; };
    MsgService = __decorate([
        Object(core["Injectable"])({
            providedIn: "root"
        }),
        __metadata("design:paramtypes", [http["HttpClient"]])
    ], MsgService);
    return MsgService;
}());


// EXTERNAL MODULE: ./app/globals/global.service.ts
var global_service = __webpack_require__(108);

// CONCATENATED MODULE: ./app/browse/browse.component.ts




var browse_component_BrowseComponent = /** @class */ (function () {
    function BrowseComponent(service, glob) {
        this.service = service;
        this.glob = glob;
        this.goldMsg = " Press the Refresh Button for the current Messeges ";
        this.firstTime = true;
        this.currentEvent = "";
        this.missionStatement = "";
        this.sponsors = "";
        this.menuIsOpen = false;
        this.devHeight = platform["screen"].mainScreen.heightPixels;
        this.itemHeight = this.devHeight / 16;
        this.devWidth = platform["screen"].mainScreen.widthPixels;
    }
    BrowseComponent.prototype.ngOnInit = function () {
        // alert(this.devHeight + "ss" + this.itemHeight);
        this.menuIsOpen = false;
        this.service.onGetData();
        this.glob.setGold(this.service.getData(0));
        this.glob.setCur(this.service.getData(1));
        this.glob.setMis(this.service.getData(2));
        this.glob.setSpon(this.service.getData(3));
        this.goldMsg = this.glob.getGold();
        this.currentEvent = this.glob.getCur();
        this.missionStatement = this.glob.getMis();
        this.sponsors = this.glob.getSpon();
        // Use the "ngOnInit" handler to initialize data for the view.
    };
    BrowseComponent.prototype.toggleMenu = function () {
        this.menuIsOpen = !this.menuIsOpen;
    };
    BrowseComponent.prototype.getGold = function () {
        return this.goldMsg;
    };
    BrowseComponent.prototype.setGold = function (mms) {
        this.goldMsg = mms;
    };
    BrowseComponent.prototype.getCur = function () {
        return this.currentEvent;
    };
    BrowseComponent.prototype.setCur = function (mms) {
        this.currentEvent = mms;
    };
    BrowseComponent.prototype.getMis = function () {
        return this.missionStatement;
    };
    BrowseComponent.prototype.setMis = function (mms) {
        this.missionStatement = mms;
    };
    BrowseComponent.prototype.getSpon = function () {
        return this.sponsors;
    };
    BrowseComponent.prototype.setSpon = function (mms) {
        this.sponsors = mms;
    };
    BrowseComponent.prototype.test = function () {
        this.service.getData(0);
    };
    BrowseComponent.prototype.length = function () {
        this.service.getL();
    };
    BrowseComponent.prototype.refresh = function () {
        this.service.onGetData();
        this.goldMsg = this.service.getData(0);
        this.currentEvent = this.service.getData(1);
        this.missionStatement = this.service.getData(2);
        this.sponsors = this.service.getData(3);
        this.firstTime = false;
        this.toggleMenu();
    };
    BrowseComponent.ctorParameters = function () { return [
        { type: notes_service_MsgService },
        { type: global_service["a" /* GlobalService */] }
    ]; };
    BrowseComponent = __decorate([
        Object(core["Component"])({
            selector: "Browse",
            template: __importDefault(__webpack_require__(489)).default,
            styles: [__importDefault(__webpack_require__(490)).default]
        }),
        __metadata("design:paramtypes", [notes_service_MsgService, global_service["a" /* GlobalService */]])
    ], BrowseComponent);
    return BrowseComponent;
}());


// CONCATENATED MODULE: ./app/browse/edit/edit.component.ts




var edit_component_EditComponent = /** @class */ (function () {
    function EditComponent(_routerExtensions, glob) {
        this._routerExtensions = _routerExtensions;
        this.glob = glob;
        this.emailControlIsValid = true;
        this.goldMsg = " Press the Refresh Button for the current Messeges ";
        this.currentEvent = "";
        this.missionStatement = "";
        this.sponsors = "";
        this.admin = false;
    }
    EditComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.goldMsg = this.glob.getGold();
        this.currentEvent = this.glob.getCur();
        this.missionStatement = this.glob.getMis();
        this.sponsors = this.glob.getSpon();
        this.admin = this.glob.isAdmin();
        this.form = new fesm5_forms["FormGroup"]({
            email: new fesm5_forms["FormControl"](null, { updateOn: "change", validators: [fesm5_forms["Validators"].required, fesm5_forms["Validators"].email] })
        });
        this.form.get("email").statusChanges.subscribe(function (status) {
            _this.emailControlIsValid = status === "VALID";
        });
    };
    EditComponent.prototype.onBackTap = function () {
        //this._routerExtensions.back();
        this._routerExtensions.back();
        this.admin = this.glob.isAdmin();
    };
    EditComponent.prototype.checkAgain = function () {
        this.glob.checkAgain();
    };
    EditComponent.prototype.makeAdmin = function () {
        this.emailEL.nativeElement.focus();
        this.emailEL.nativeElement.dismissSoftInput();
        if (!this.form.valid) {
            alert("Something went wrong, check what was entered");
            return;
        }
        var email = this.form.get("email").value;
        this.emailControlIsValid = true;
        alert(email);
        this.glob.makeAAdmin(email);
    };
    EditComponent.prototype.isAdmin = function () {
        alert(this.glob.isAdmin());
    };
    EditComponent.ctorParameters = function () { return [
        { type: router["RouterExtensions"] },
        { type: global_service["a" /* GlobalService */] }
    ]; };
    __decorate([
        Object(core["ViewChild"])("emailEL", null),
        __metadata("design:type", core["ElementRef"])
    ], EditComponent.prototype, "emailEL", void 0);
    EditComponent = __decorate([
        Object(core["Component"])({
            selector: "ns-edit",
            template: __importDefault(__webpack_require__(491)).default,
            styles: [__importDefault(__webpack_require__(492)).default]
        }),
        __metadata("design:paramtypes", [router["RouterExtensions"],
            global_service["a" /* GlobalService */]])
    ], EditComponent);
    return EditComponent;
}());


// CONCATENATED MODULE: ./app/browse/browse.module.ts
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BrowseModule", function() { return browse_module_BrowseModule; });









var browse_module_BrowseModule = /** @class */ (function () {
    function BrowseModule() {
    }
    BrowseModule = __decorate([
        Object(core["NgModule"])({
            imports: [
                common["NativeScriptCommonModule"],
                router["NativeScriptRouterModule"],
                angular_forms["NativeScriptFormsModule"],
                fesm5_forms["ReactiveFormsModule"],
                http_client["NativeScriptHttpClientModule"],
                router["NativeScriptRouterModule"].forChild([
                    { path: "", redirectTo: "default" },
                    { path: "default", component: browse_component_BrowseComponent },
                    { path: "edit", component: edit_component_EditComponent }
                ])
            ],
            providers: [
                notes_service_MsgService,
                { provide: core["ErrorHandler"] },
                { provide: core["NgModuleFactoryLoader"], useClass: router["NSModuleFactoryLoader"] }
            ],
            declarations: [
                browse_component_BrowseComponent, edit_component_EditComponent
            ],
            schemas: [
                core["NO_ERRORS_SCHEMA"]
            ]
        })
    ], BrowseModule);
    return BrowseModule;
}());



/***/ })

}]);