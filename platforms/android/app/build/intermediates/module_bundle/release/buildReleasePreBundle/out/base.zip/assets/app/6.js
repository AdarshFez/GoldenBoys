(global["webpackJsonp"] = global["webpackJsonp"] || []).push([[6],{

/***/ 493:
/***/ (function(module, exports) {

module.exports = "<ActionBar class = \"title\">\n    <GridLayout>\n    <Label class = ff text=\"Events\"></Label>\n    <button class = \"command\" text = Options (tap) = \"toggleMenu()\"></button>\n</GridLayout>\n</ActionBar>\n\n<!--\n\n<StackLayout height=\"100%\"  class=\"m-15\" backgroundColor=\"lightgray\"> -->\n\n    <!-- Image with CSS and an icon fonts -->\n\n    <!-- Image with stretch property (\"none\", \"aspectFill\" and \"aspectFit\") -->\n\n    <!-- <Image src=\"~/app/search/beach.jpg\" stretch=\"aspectFill\"></Image>\n</StackLayout> -->\n\n\n<!-- <img class=\"BigEvent\" src=\"./beach.jpg\"> -->\n\n\n<StackLayout *ngIf =\"!menuIsOpen\"  class=\"page__content\">\n    <Image class = \"pic\" [width] = devWidth [height]= devHeight src=\"~/app/search/box.jpg\" stretch=\"aspectFit\"></Image>\n</StackLayout>\n\n<StackLayout *ngIf =\"menuIsOpen\"  >\n\n    <Button class = \"command\" text=\"Log Out \" [nsRouterLink]=\"['']\"> </Button>\n\n    <Button text=\"close menu\" class=\"menu-item\" (tap)= \"toggleMenu()\"></Button>\n\n\n</StackLayout>\n\n\n"

/***/ }),

/***/ 497:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ../node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js
var core = __webpack_require__(0);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/common.js
var common = __webpack_require__(178);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/router/index.js
var router = __webpack_require__(89);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/forms/index.js
var angular_forms = __webpack_require__(179);

// EXTERNAL MODULE: ../node_modules/@nativescript/core/platform/platform.js
var platform = __webpack_require__(20);

// CONCATENATED MODULE: ./app/search/search.component.ts


var search_component_SearchComponent = /** @class */ (function () {
    function SearchComponent() {
        this.menuIsOpen = false;
        this.devHeight = platform["screen"].mainScreen.heightPixels;
        this.devWidth = platform["screen"].mainScreen.widthPixels;
    }
    SearchComponent.prototype.toggleMenu = function () {
        this.menuIsOpen = !this.menuIsOpen;
        alert(this.devHeight);
    };
    SearchComponent = __decorate([
        Object(core["Component"])({
            selector: "Search",
            template: __importDefault(__webpack_require__(493)).default
            // styleUrls: ["./search.component.css"]
        })
    ], SearchComponent);
    return SearchComponent;
}());


// CONCATENATED MODULE: ./app/search/search.module.ts
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchModule", function() { return search_module_SearchModule; });





var search_module_SearchModule = /** @class */ (function () {
    function SearchModule() {
    }
    SearchModule = __decorate([
        Object(core["NgModule"])({
            imports: [
                common["NativeScriptCommonModule"],
                router["NativeScriptRouterModule"],
                angular_forms["NativeScriptFormsModule"],
                router["NativeScriptRouterModule"].forChild([
                    { path: "", redirectTo: "default" },
                    { path: "default", component: search_component_SearchComponent }
                ])
            ],
            declarations: [
                search_component_SearchComponent
            ],
            providers: [],
            schemas: [
                core["NO_ERRORS_SCHEMA"]
            ]
        })
    ], SearchModule);
    return SearchModule;
}());



/***/ })

}]);