if (global.__onLiveSync) {
	global.__onLiveSync();
}