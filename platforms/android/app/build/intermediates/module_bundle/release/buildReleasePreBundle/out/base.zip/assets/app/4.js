(global["webpackJsonp"] = global["webpackJsonp"] || []).push([[4],{

/***/ 485:
/***/ (function(module, exports) {

module.exports = "\r\n<ActionBar class = \"title\" >\r\n    <!-- <GridLayout> -->\r\n    <GridLayout class = top>\r\n        <Label class = titleText text=\"Donations\"></Label>\r\n        <button class = \"command\" text = Options (tap) = \"toggleMenu()\"></button>\r\n    </GridLayout>\r\n    <!-- </GridLayout> -->\r\n\r\n</ActionBar>\r\n\r\n\r\n\r\n<GridLayout *ngIf =\"!menuIsOpen\" class = \"page__content\">\r\n    <ListView [items]=\"items\">\r\n        <ng-template let-item=\"item\">\r\n            <StackLayout>\r\n                <Label [nsRouterLink]=\"['../item', item.id]\" [text]=\"item.id + '. Name: ' +item.name\"></Label>\r\n\r\n            </StackLayout>\r\n        </ng-template>\r\n    </ListView>\r\n\r\n</GridLayout>\r\n\r\n<StackLayout *ngIf =\"menuIsOpen\"  >\r\n\r\n    <Button class = \"command\" text=\"Make A Donation\" [nsRouterLink]=\"['../action']\" pageTransition=\"slide\" ></Button>\r\n    <Button class = \"command\" text=\"refresh \" (tap)=\"refreshItems()\" ></Button>\r\n    <Button class = \"command\" text=\"Log Out \" [nsRouterLink]=\"['']\"> </Button>\r\n    <Button text=\"close menu\" class=\"menu-item\" (tap)= \"toggleMenu()\"></Button>\r\n\r\n</StackLayout>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n"

/***/ }),

/***/ 486:
/***/ (function(module, exports) {

module.exports = "<ActionBar>\r\n    <NavigationButton (tap)=\"onBackTap()\" android.systemIcon=\"ic_menu_back\"></NavigationButton>\r\n    <Label [text]=\"item.name\"></Label>\r\n</ActionBar>\r\n\r\n<StackLayout *ngIf = admin&&!first>\r\n    <Label class=\"m-10 h3\" verticalAlignment=\"top\" [text]=\"'Name is: ' + item.name\"></Label>\r\n    <Label class=\"m-10 h3\" verticalAlignment=\"top\" [text]=\"'This item is: ' + item.description\"></Label>\r\n    <Label class=\"m-10 h3\" verticalAlignment=\"top\" [text]=\"'The address is: '+item.address\"></Label>\r\n    <Label class=\"m-10 h3\" verticalAlignment=\"top\" [text]=\"'The time is: '+item.time\"></Label>\r\n    <Label class=\"m-10 h3\" verticalAlignment=\"top\" [text]=\"'This phone number is: ' +item.phone\"></Label>\r\n</StackLayout>\r\n\r\n<StackLayout *ngIf = !admin&&!first>\r\n    <Label class=\"m-10 h3\" verticalAlignment=\"top\" [text]=\"'This item is: ' + item.description\"></Label>\r\n    <Label class=\"m-10 h3\" verticalAlignment=\"top\" text = \"To See more please log in with an Admin Account\"> </Label>\r\n</StackLayout>\r\n\r\n<StackLayout *ngIf = first>\r\n    <label class = \"m-10 h3\" text = \"Hello Welcome to the Donation help, Click on the Options to refresh the page and go to the make a donation page\" textWrap = \"true\"></label>\r\n</StackLayout>\r\n"

/***/ }),

/***/ 487:
/***/ (function(module, exports) {

module.exports = "<ActionBar>\r\n       <Label text=\"Action Menu\"></Label>\r\n       <NavigationButton (tap)=\"onBackTap()\" android.systemIcon=\"ic_menu_back\"></NavigationButton>\r\n   </ActionBar>\r\n   <ScrollView orientation=\"vertical\">\r\n   <StackLayout class = \"Questions\" [formGroup]=\"form\" VerticalOption = FillAndExpand>\r\n       <button text = \"delete or switch\" (tap)= \"onSwitch()\"></button>\r\n          <StackLayout *ngIf= dona class = \"adding\" [formGroup]=\"form\">\r\n\r\n\r\n                   <Label class =\"label\"\r\n                     [ngClass]=\"{invalid: nameControlValid }\"\r\n                   ></Label>\r\n                   <TextField\r\n                        hint=\"Enter name here\"\r\n                        class = \"input\"\r\n                        returnKeyType=\"next\"\r\n                        required\r\n                        formControlName=\"name\"\r\n                        #nameEL\r\n                   ></TextField>\r\n                   <label *ngIf=\"!nameControlValid\" text =\"please enter a Name\"></label>\r\n\r\n                   <Label class =\"label\"\r\n                       [ngClass]=\"{ invald: itemControlValid }\"\r\n                   ></Label>\r\n                   <TextField\r\n                        hint=\"Enter item here\"\r\n                        class = \"input\"\r\n                        returnKeyType=\"next\"\r\n                        formControlName=\"item\"\r\n                        #itemEL\r\n                   ></TextField>\r\n                   <label *ngIf=\"!itemControlValid\" text =\"please enter a Item\"></label>\r\n\r\n                   <Label class =\"label\"\r\n                       [ngClass]=\"{ invald: addressControlValid }\"\r\n                   ></Label>\r\n                   <TextField\r\n                        hint=\"Enter address here\"\r\n                        class = \"input\"\r\n                        returnKeyType=\"next\"\r\n                        formControlName=\"address\"\r\n                        #addressEL\r\n                   ></TextField>\r\n                   <label *ngIf=\"!addressControlValid\" text =\"please enter a valid Address\"></label>\r\n\r\n                   <DatePicker class = \"datePicked\" year=\"2020\" month=\"4\" day=\"20\"\r\n                        [minDate]=\"minDate\" [maxDate]=\"maxDate\"\r\n                        (dateChange)=\"onDateChanged($event)\"\r\n                        (dayChange)=\"onDayChanged($event)\"\r\n                        (monthChange)=\"onMonthChanged($event)\"\r\n                        (yearChange)=\"onYearChanged($event)\"\r\n                        (loaded)=\"onDatePickerLoaded($event)\"\r\n                        verticalAlignment=\"center\">\r\n                    </DatePicker>\r\n\r\n\r\n\r\n                   <Label class =\"label\"\r\n                       [ngClass]=\"{ invald: timeControlValid }\"\r\n                   ></Label>\r\n                   <TextField\r\n                        hint=\"Enter time and add Am or PM , EX:  4 PM\"\r\n                        class = \"input\"\r\n                        returnKeyType=\"next\"\r\n                        formControlName=\"time\"\r\n                        #timeEL\r\n                   ></TextField>\r\n                   <label *ngIf=\"!timeControlValid\" text =\"please enter a Time\"></label>\r\n\r\n                   <Label class =\"label\"\r\n                       [ngClass]=\"{ invald: phoneControlValid }\"\r\n                   ></Label>\r\n                   <TextField\r\n                        hint=\"Enter phone number as XXXXXXXXXX\"\r\n                        class = \"input\"\r\n                        keyboardType=\"phone\"\r\n                        returnKeyType=\"done\"\r\n                        formControlName=\"phone\"\r\n                        #phoneEL\r\n                   ></TextField>\r\n                   <label *ngIf=\"!phoneControlValid\" text =\"please enter a phone number with area code \"></label>\r\n\r\n\r\n                 <Button class = \"butto\" text=\"Make a new Donation\" (tap)=\"local()\" ></Button>\r\n                 <Button *ngIf = !notChanged class =\"butto\" text=\"Delete the Donation you just made\" (tap) = \"unLocal()\"></Button>\r\n                 <Button class = \"butto\" [disabled] = !notChanged text=\"All Set\" (tap)=\"onSend()\" ></Button>\r\n          </StackLayout>\r\n          <StackLayout *ngIf=\"!dona\" class = \"dele\">\r\n            <label text = \"Enter Number you want deleted here\" ></label>\r\n            <Label class =\"label\"\r\n                         [ngClass]=\"{ invald: deleteControlValid }\"\r\n            ></Label>\r\n\r\n            <label *ngIf=\"!deleteControlValid\" text =\"please enter a number you want to delete\"></label>\r\n                  <TextField hint=\"Enter Number you want deleted here\"\r\n                      [text]='deleteNum'\r\n                      keyboardType=\"datetime\"\r\n                      returnKeyType=\"done\"\r\n                      (textChange)=\"onReturnPressD($event)\"\r\n                  ></TextField>\r\n            <Button text = 'press to delete the number entered' (tap)=\"delete()\"  [isEnabled] = \"!dona\"></Button>\r\n            </StackLayout>\r\n          <label text = \"Hit All set after any changes\" ></label>\r\n\r\n   <!-- <Button text=\"Refresh List \" (tap)=\"onRefresh()\" ></Button> -->\r\n   <!-- help -->\r\n   </StackLayout>\r\n</ScrollView>\r\n\r\n"

/***/ }),

/***/ 488:
/***/ (function(module, exports) {

module.exports = ".dialogOpen .content {\r\n    opacity: 0.2;\r\n  }\r\n  .dialogOpen .dialog-wrapper {\r\n    visibility: visible;\r\n  }\r\n  .dialog-wrapper {\r\n    visibility: collapse;\r\n  }\r\n  .dialog {\r\n    border-width: 1 0 1 0;\r\n    border-color: black;\r\n    width: 100%;\r\n    margin-top: 100;\r\n  }\r\n\r\n.Questions {\r\n  padding-top: 10px;\r\n  align-content: center;\r\n  text-align: center;\r\n}\r\n\r\n.butto {\r\n  color: black;\r\n}\r\n\r\n.datePicked {\r\n  /* background-color: olivedrab; */\r\n  /* border-color: burlywood; */\r\n  border-width: 2;\r\n  border-radius: 10;\r\n  color: whitesmoke;\r\n  vertical-align: middle;\r\n}\r\n\r\n.Questions{\r\n  color: black;\r\n}\r\n"

/***/ }),

/***/ 494:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: ../node_modules/@angular/core/__ivy_ngcc__/fesm5/core.js
var core = __webpack_require__(0);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/common.js
var common = __webpack_require__(178);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/router/index.js
var router = __webpack_require__(89);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/http-client/index.js
var http_client = __webpack_require__(180);

// EXTERNAL MODULE: ../node_modules/@nativescript/angular/forms/index.js
var angular_forms = __webpack_require__(179);

// EXTERNAL MODULE: ../node_modules/@angular/forms/__ivy_ngcc__/fesm5/forms.js
var fesm5_forms = __webpack_require__(27);

// EXTERNAL MODULE: ../node_modules/@angular/common/__ivy_ngcc__/fesm5/http.js
var http = __webpack_require__(66);

// CONCATENATED MODULE: ./app/shared/data.service.ts


var data_service_DataService = /** @class */ (function () {
    function DataService(http) {
        this.http = http;
        this.url = "https://goldenboys-be087.firebaseio.com/items.json";
        // tslint:disable-next-line: variable-name
        this.items = new Array({
            id: 1,
            name: "Help Menu",
            description: " Hit Refresh to see current active, Hit Action menu",
            address: "Press the 'Done Hit me' after every entry",
            date: "04/23/2020",
            time: "Then hit 'Make a new Donatoin'",
            phone: 0
        }
        // {
        //     id: 2,
        //     name: "cornnn John",
        //     description: "Paper",
        //     address: "32 sddf",
        //     time: "8 pm ",
        //     phone: 4728955
        // }
        );
    }
    DataService.prototype.getItems = function () {
        return this.items;
    };
    DataService.prototype.makeId = function () {
        return this.items.length;
    };
    DataService.prototype.getItem = function (id) {
        return this.items.filter(function (item) { return item.id === id; })[0];
    };
    DataService.prototype.makeItemLocal = function (nam, des, add, day, tim, phone) {
        var temp = { id: 0, name: "", description: "", address: "", date: "", time: "", phone: 0 };
        temp.id = this.items.length + 1;
        temp.name = nam;
        temp.description = des;
        temp.address = add;
        temp.date = day;
        temp.time = tim;
        temp.phone = phone;
        this.items.push(temp);
        alert("made local");
    };
    DataService.prototype.sendAll = function () {
        this.http.put(this.url, this.items).subscribe();
    };
    DataService.prototype.refresh = function () {
        return this.http.get(this.url);
    };
    DataService.prototype.localLength = function () {
        return this.items.length;
    };
    DataService.prototype.getItemNum = function (num) {
        for (var i = 0; i < this.items.length; i++) {
            if (this.items[i].id === num) {
                return i + 1;
            }
        }
        // alert("not in array returning" + -1);
        return -1;
    };
    DataService.prototype.delete = function (location) {
        var i = this.items.length;
        var tempitems = new Array();
        while (i > location) {
            tempitems.push(this.items.pop());
            i--;
        }
        this.items.pop();
        i = tempitems.length;
        while (i !== 0) {
            this.items.push(tempitems.pop());
            i--;
        }
        alert(" Its out of here ");
    };
    DataService.prototype.onGetData = function () {
        var _this = this;
        this.http.get(this.url).subscribe(function (data) { return _this.items = data; });
    };
    DataService.prototype.reorder = function () {
        var i = 1;
        while (i <= this.items.length) {
            this.items[i - 1].id = i;
            i++;
        }
    };
    DataService.prototype.testing = function () {
        alert("got to service");
        var str = "testing one two";
        this.http.put("https://goldenboys-be087.firebaseio.com/test.json", str).subscribe();
    };
    DataService.ctorParameters = function () { return [
        { type: http["HttpClient"] }
    ]; };
    DataService = __decorate([
        Object(core["Injectable"])({
            providedIn: "root"
        }),
        __metadata("design:paramtypes", [http["HttpClient"]])
    ], DataService);
    return DataService;
}());


// CONCATENATED MODULE: ./app/home/home.component.ts


var home_component_HomeComponent = /** @class */ (function () {
    function HomeComponent(_itemService) {
        this._itemService = _itemService;
        this.menuIsOpen = false;
    }
    HomeComponent.prototype.ngOnInit = function () {
        this._itemService.onGetData();
        this.items = this._itemService.getItems();
    };
    HomeComponent.prototype.refreshItems = function () {
        this._itemService.onGetData();
        this.items = this._itemService.getItems();
        this.toggleMenu();
    };
    HomeComponent.prototype.toggleMenu = function () {
        this.menuIsOpen = !this.menuIsOpen;
    };
    HomeComponent.ctorParameters = function () { return [
        { type: data_service_DataService }
    ]; };
    HomeComponent = __decorate([
        Object(core["Component"])({
            selector: "Home",
            template: __importDefault(__webpack_require__(485)).default
            //styleUrls: ["./home.component.css"]
        }),
        __metadata("design:paramtypes", [data_service_DataService])
    ], HomeComponent);
    return HomeComponent;
}());


// EXTERNAL MODULE: ../node_modules/@angular/router/__ivy_ngcc__/fesm5/router.js
var fesm5_router = __webpack_require__(74);

// EXTERNAL MODULE: ./app/globals/global.service.ts
var global_service = __webpack_require__(108);

// CONCATENATED MODULE: ./app/home/item-detail/item-detail.component.ts





var item_detail_component_ItemDetailComponent = /** @class */ (function () {
    function ItemDetailComponent(_data, _route, _routerExtensions, glob) {
        this._data = _data;
        this._route = _route;
        this._routerExtensions = _routerExtensions;
        this.glob = glob;
        this.admin = false;
        this.first = false;
    }
    ItemDetailComponent.prototype.ngOnInit = function () {
        var id = +this._route.snapshot.params.id;
        this.item = this._data.getItem(id);
        this.admin = this.glob.isAdmin();
        if (id === 1) {
            this.first = true;
        }
    };
    ItemDetailComponent.prototype.onBackTap = function () {
        this._routerExtensions.back();
        this.first = false;
    };
    ItemDetailComponent.ctorParameters = function () { return [
        { type: data_service_DataService },
        { type: fesm5_router["ActivatedRoute"] },
        { type: router["RouterExtensions"] },
        { type: global_service["a" /* GlobalService */] }
    ]; };
    ItemDetailComponent = __decorate([
        Object(core["Component"])({
            selector: "ItemDetail",
            template: __importDefault(__webpack_require__(486)).default
        }),
        __metadata("design:paramtypes", [data_service_DataService,
            fesm5_router["ActivatedRoute"],
            router["RouterExtensions"],
            global_service["a" /* GlobalService */]])
    ], ItemDetailComponent);
    return ItemDetailComponent;
}());


// EXTERNAL MODULE: ../node_modules/@nativescript/core/utils/utils.js
var utils = __webpack_require__(28);

// EXTERNAL MODULE: ../node_modules/@nativescript/core/utils/types.js
var types = __webpack_require__(43);

// CONCATENATED MODULE: ./app/home/action/action.component.ts







var action_component_ActionComponent = /** @class */ (function () {
    function ActionComponent(service, _routerExtensions, glob) {
        this.service = service;
        this._routerExtensions = _routerExtensions;
        this.glob = glob;
        this.deleteNum = 0;
        this.nim = 0;
        this.notChanged = true;
        this.dona = true;
        this.nameControlValid = true;
        this.timeControlValid = true;
        this.phoneControlValid = true;
        this.addressControlValid = true;
        this.dateControlValid = true;
        this.itemControlValid = true;
        this.deleteControlValid = true;
        this.minDate = new Date(2020, 3, 23);
        this.maxDate = new Date(2025, 4, 12);
        this.date = "";
        this.month = 4;
        this.day = 23;
        this.year = 2020;
        this.error = "";
    }
    ActionComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.form = new fesm5_forms["FormGroup"]({
            name: new fesm5_forms["FormControl"](null, { updateOn: "blur" }),
            item: new fesm5_forms["FormControl"](null, { updateOn: "change", validators: [fesm5_forms["Validators"].required,
                    fesm5_forms["Validators"].minLength(3)] }),
            address: new fesm5_forms["FormControl"](null, { updateOn: "change", validators: [fesm5_forms["Validators"].required,
                    fesm5_forms["Validators"].minLength(3)] }),
            time: new fesm5_forms["FormControl"](null, { updateOn: "change", validators: [fesm5_forms["Validators"].required,
                    fesm5_forms["Validators"].minLength(3)] }),
            phone: new fesm5_forms["FormControl"](null, { updateOn: "change", validators: [fesm5_forms["Validators"].required,
                    fesm5_forms["Validators"].minLength(10)] })
        });
        this.form.get("name").statusChanges.subscribe(function (status) {
            _this.nameControlValid = status === "VALID";
        });
        this.form.get("item").statusChanges.subscribe(function (status) {
            _this.itemControlValid = status === "VALID";
        });
        this.form.get("phone").statusChanges.subscribe(function (status) {
            _this.phoneControlValid = status === "VALID";
        });
        this.form.get("address").statusChanges.subscribe(function (status) {
            _this.addressControlValid = status === "VALID";
        });
        this.form.get("time").statusChanges.subscribe(function (status) {
            _this.timeControlValid = status === "VALID";
        });
        console.log(this.nameControlValid, this.itemControlValid, this.phoneControlValid, this.addressControlValid, this.itemControlValid);
    };
    ActionComponent.prototype.onBackTap = function () {
        if (this.notChanged) {
            this._routerExtensions.back();
        }
        else {
            alert("sorry you made an item you have to sync to go back otherwise delete it");
        }
    };
    //  onReturnPressN(args) {
    //     // returnPress event will be triggered when user submits a value
    //     const textField = <TextField>args.object;
    //     this.name = textField.text;
    //  }
    // alert("If any of the data is not correct fix it before hitting the 'make a donation'");
    ActionComponent.prototype.onReturnPressD = function (args) {
        // returnPress event will be triggered when user submits a value
        var textField = args.object;
        this.deleteNum = Number(textField.text);
    };
    // sends everything
    ActionComponent.prototype.onSend = function () {
        this.service.sendAll();
        this.notChanged = !this.notChanged;
        // alert(email + password);
    };
    // make object locally
    // this.service.makeItemLocal(this.name , this.item, this.address, this.time, this.phonee);
    ActionComponent.prototype.local = function () {
        this.nameEL.nativeElement.focus();
        this.addressEL.nativeElement.focus();
        this.timeEL.nativeElement.focus();
        this.phoneEL.nativeElement.focus();
        this.itemEL.nativeElement.focus();
        this.itemEL.nativeElement.dismissSoftInput();
        this.date = this.month + "/" + this.day + "/" + this.year;
        var namee = this.form.get("name").value;
        var name = " " + namee + " ";
        var itemm = this.form.get("item").value;
        var item = itemm.toString();
        var addresss = this.form.get("address").value;
        var address = addresss.toString();
        var timee = this.form.get("time").value;
        var time = timee.toString();
        var datee = this.date;
        var date = datee.toString();
        var phone = this.form.get("phone").value;
        console.log("the name : " + name + " The Item  : " +
            item + " The address  : " + address + " The Time  : " + "The Date of:" + date
            + time + " The Item  : " + phone);
        console.log(this.date);
        if (!this.form.valid) {
            alert("form failed");
            return;
        }
        // this.form.reset();
        this.nameControlValid = true;
        this.timeControlValid = true;
        this.phoneControlValid = true;
        this.addressControlValid = true;
        this.dateControlValid = true;
        this.itemControlValid = true;
        if (Object(types["isString"])(name) && this.notNumberCheck(name)) {
            if (this.stringCheck(item) && this.notNumberCheck(item)) {
                if (this.stringCheck(address) && this.notNumberCheck(address)) {
                    if (this.stringCheck(time) && this.notNumberCheck(time)) {
                        if (this.stringCheck(date) && this.notNumberCheck(date)) {
                            var phon = Object(utils["convertString"])(phone);
                            if (!this.notNumberCheck(phon)) {
                                this.error = "works";
                            }
                            else {
                                this.error = "phone";
                            }
                        }
                        else {
                            this.error = "date";
                        }
                    }
                    else {
                        this.error = "time";
                    }
                }
                else {
                    this.error = "address";
                }
            }
            else {
                this.error = "item";
            }
        }
        else {
            this.error = "name";
        }
        if (this.error !== "works") {
            alert("Check what you entered for " + this.error);
            return;
        }
        console.log(this.localsize());
        this.service.makeItemLocal(name, item, address, date, time, phone);
        this.notChanged = false;
        alert("A Donations with the name : " + name + " The Item  : " +
            item + " The address  : " + address + "The date of: " + date + " The Time  : "
            + time + " The Item  : " + phone + "if this looks good hit all set!" + "error" + this.error);
        console.log(this.localsize());
    };
    // get local size
    ActionComponent.prototype.localsize = function () {
        alert(this.service.localLength());
    };
    ActionComponent.prototype.unLocal = function () {
        this.service.delete(this.service.localLength());
        this.notChanged = !this.notChanged;
    };
    // delete number you enter
    ActionComponent.prototype.delete = function () {
        var del = Object(utils["convertString"])(this.deleteNum);
        if (del <= 1) {
            alert("Sorry Can not delete That one");
            console.log(del);
        }
        else {
            this.nim = this.service.getItemNum(this.deleteNum);
            //alert("passed zerooooo" + this.nim);
            if (this.nim === -1) {
                alert("Sorry item does not exist");
                //alert("Sorry item does not exist");
            }
            else {
                this.service.delete(this.service.getItemNum(this.deleteNum));
                this.service.reorder();
                this.notChanged = this.notChanged;
            }
        }
    };
    ActionComponent.prototype.onDatePickerLoaded = function (args) {
        console.log(args.value);
    };
    ActionComponent.prototype.onDateChanged = function (args) {
        var none = args.value;
    };
    ActionComponent.prototype.onDayChanged = function (args) {
        this.day = args.value;
        console.log(args.value);
    };
    ActionComponent.prototype.onMonthChanged = function (args) {
        this.month = args.value;
        console.log(args.value);
    };
    ActionComponent.prototype.onYearChanged = function (args) {
        this.year = args.value;
        console.log(args.value);
    };
    ActionComponent.prototype.onSwitch = function () {
        if (this.glob.isAdmin()) {
            this.dona = !this.dona;
        }
        else {
            alert("Sorry Only admins can hit that button");
        }
    };
    ActionComponent.prototype.notNumberCheck = function (num) {
        var phon = Object(utils["convertString"])(num);
        if (phon % 2 === 1 || num % 2 === 0) {
            return false;
        }
        else {
            return true;
        }
    };
    ActionComponent.prototype.stringCheck = function (num) {
        if (Object(types["isString"])(num)) {
            //alert("string");
            return true;
        }
        else {
            //alert("notString");
            return false;
        }
    };
    ActionComponent.ctorParameters = function () { return [
        { type: data_service_DataService },
        { type: router["RouterExtensions"] },
        { type: global_service["a" /* GlobalService */] }
    ]; };
    __decorate([
        Object(core["ViewChild"])("nameEL", null),
        __metadata("design:type", core["ElementRef"])
    ], ActionComponent.prototype, "nameEL", void 0);
    __decorate([
        Object(core["ViewChild"])("itemEL", null),
        __metadata("design:type", core["ElementRef"])
    ], ActionComponent.prototype, "itemEL", void 0);
    __decorate([
        Object(core["ViewChild"])("timeEL", null),
        __metadata("design:type", core["ElementRef"])
    ], ActionComponent.prototype, "timeEL", void 0);
    __decorate([
        Object(core["ViewChild"])("addressEL", null),
        __metadata("design:type", core["ElementRef"])
    ], ActionComponent.prototype, "addressEL", void 0);
    __decorate([
        Object(core["ViewChild"])("phoneEL", null),
        __metadata("design:type", core["ElementRef"])
    ], ActionComponent.prototype, "phoneEL", void 0);
    ActionComponent = __decorate([
        Object(core["Component"])({
            selector: "actionIt",
            template: __importDefault(__webpack_require__(487)).default,
            styles: [__importDefault(__webpack_require__(488)).default]
        }),
        __metadata("design:paramtypes", [data_service_DataService,
            router["RouterExtensions"],
            global_service["a" /* GlobalService */]])
    ], ActionComponent);
    return ActionComponent;
}());


// CONCATENATED MODULE: ./app/home/home.module.ts
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeModule", function() { return home_module_HomeModule; });










// import { ActionModule } from "../action/action.module";
var home_module_HomeModule = /** @class */ (function () {
    function HomeModule() {
    }
    HomeModule = __decorate([
        Object(core["NgModule"])({
            imports: [
                common["NativeScriptCommonModule"],
                router["NativeScriptRouterModule"],
                http_client["NativeScriptHttpClientModule"],
                angular_forms["NativeScriptFormsModule"],
                fesm5_forms["ReactiveFormsModule"],
                router["NativeScriptRouterModule"].forChild([
                    { path: "", redirectTo: "default" },
                    { path: "default", component: home_component_HomeComponent },
                    { path: "item/:id", component: item_detail_component_ItemDetailComponent },
                    { path: "action", component: action_component_ActionComponent }
                ])
            ],
            providers: [
                data_service_DataService,
                { provide: core["ErrorHandler"] },
                { provide: core["NgModuleFactoryLoader"], useClass: router["NSModuleFactoryLoader"] }
            ],
            declarations: [
                home_component_HomeComponent,
                item_detail_component_ItemDetailComponent,
                action_component_ActionComponent
            ],
            schemas: [
                core["NO_ERRORS_SCHEMA"]
            ]
        })
    ], HomeModule);
    return HomeModule;
}());



/***/ })

}]);